#include <stdlib.h>
#include <fstream>
#include <string>
#include <sys/wait.h>   /* for wait() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <sys/mman.h>   /* for mmap() ) */
#include <semaphore.h>  /* for sem */
#include <assert.h>		/* for assert */
#include <iostream>     /* for cout */
#include <list>
#include <array>
#include <pthread.h> 

using namespace std;

int glob_ct = 0; 

pthread_mutex_t coutlock = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t l1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t l2 = PTHREAD_MUTEX_INITIALIZER;

void* dataracejob(void *threadnum){
    int mynum = *((int *) threadnum); // Copy my num
    free(threadnum); // Free the Malloc
    pthread_mutex_lock(&coutlock);
    cout << "My number is " << mynum <<endl; // Print num
    pthread_mutex_unlock(&coutlock);

    return NULL;
}

void* job(void *threadnum){
    int mynum = *((int *) threadnum); // Copy my num
    free(threadnum); // Free the Malloc

    pthread_mutex_lock(&coutlock);
    cout << "My number is " << mynum <<endl; // Print num
    pthread_mutex_unlock(&coutlock);

    pthread_mutex_lock(&l1); // LOCK L1 Before Checking Global
    while(-30 < glob_ct && glob_ct < 30){ // CHECK: if Global Count < 30: 
        pthread_mutex_unlock(&l1);
        
        if (mynum % 2 == 0){ // EVEN
            pthread_mutex_lock(&l1); // LOCK L1
            pthread_mutex_lock(&coutlock); // LOCK COUTLOCK
            cout << "even thread " << mynum << " worked: " << glob_ct << "++2" << endl;
            pthread_mutex_unlock(&coutlock); // UNLOCK COUTLOCK
            glob_ct += 2; // INCREMENT GLOBAL COUNT
            pthread_mutex_unlock(&l1); // UNLOCK L1
        } 
        if (mynum % 2 == 1){ // ODD

            pthread_mutex_lock(&l1); // LOCK L1 // A: SWITCH WITH B FOR DEADLOCK
            pthread_mutex_lock(&coutlock); // LOCK COUTLOCK // B: SWITCH WITH A FOR DEADLOCK

            cout << "odd thread " << mynum << " worked: " << glob_ct << "--" << endl;
            pthread_mutex_unlock(&coutlock); // UNLOCK COUTLOCK
            glob_ct--; // DECREMENT GLOBAL COUNT
            pthread_mutex_unlock(&l1); // UNLOCK L1
        }

        pthread_mutex_lock(&l1); // LOCK L1 Before Checking Global 
    }
    pthread_mutex_unlock(&l1); // UNLOCK L1 After Checking Global

    return NULL;
}



void* threadmisusejob(void *args){ // DEMONSTRATES LOCK ERROR

    pthread_mutex_lock(&l1); // LOCK L1 Before Checking Global
    while(glob_ct < 10){ // CHECK: if Global Count < 10: 
        glob_ct++;
        cout << glob_ct << "++" << endl;
        pthread_mutex_lock(&l1); // LOCK L1 Before Checking Global 
    }
    pthread_mutex_unlock(&l1); // UNLOCK L1 After Checking Global

    return NULL;
}


int main(int argc, char* argv[]) {    
    int n = 6; // N: Number of Threads
    pthread_t threads[n]; // Declare N Threads

    // COMMENT OUT/IN MAIN VARIATIONS TO SEE THE THREAD ERRORS: //

    // /////// Misuse MAIN //////
    // cout << "Misuse" << endl;
    // for(int i=0;i<n;i++){ // CREATE N threads
    //     pthread_create(&threads[i], NULL, &threadmisusejob, NULL); 
    // }
    // for(int i=0;i<n;i++){ // DELETE N threads
    //     pthread_join(threads[i], NULL); 
    // }
    // ////////////////////////

    // //////DATA RACE MAIN //////
    // int numthreads = -1; 
    // for(int i=0;i<n;i++){ // CREATE N threads
    //     numthreads = i+2; 
    //     pthread_create(&threads[i], NULL, &dataracejob, &numthreads); 
    // }
    // ///////////////////////////

    // FIXED DATA RACE/DEADLOCK MAIN://
    for(int i=0;i<n;i++){ // CREATE N threads
        // MALLOC Space for an INT and send it
        int *t = (int *) malloc(sizeof(t)); 
        *t = (i+2);
        pthread_create(&threads[i], NULL, &job, t); 
    }
    for(int i=0;i<n;i++){ // DELETE N threads
        pthread_join(threads[i], NULL); 
    }
    ////////////////////////////////////

    return 0;
}
