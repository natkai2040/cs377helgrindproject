#include <ledger.h>

using namespace std;


pthread_mutex_t ledger_lock = PTHREAD_MUTEX_INITIALIZER;
list<struct Ledger> ledger;
Bank *bank;

/**
 * @brief creates a new bank object and sets up workers
 * 
 * Requirements:
 *  - Create a new Bank object class with 10 accounts.
 *  - Load the ledger into a list
 *  - Set up the worker threads.  
 *  
 * @param num_workers 
 * @param filename 
 */
void InitBank(int num_workers, char *filename) {
	bank = new Bank(10); 
	bank->print_account(); 
	load_ledger(filename);
	pthread_mutex_init(&ledger_lock, NULL);

	list<int> l;
	pthread_t workers[num_workers];
	for (int i=0; i<num_workers; i++) {
		l.push_front(i);
		pthread_create(&workers[i], NULL, worker, &(l.front())); 
	}
	for (int i=0; i < num_workers; i++){
       pthread_join(workers[i], NULL);
	//    cout << "WORKER " + to_string(i) + " TERMINATED" <<endl;
	}
	bank->print_account(); 
	pthread_mutex_destroy(&ledger_lock); 
	free(bank); 
}

/**
 * @brief Parse a ledger file and store each line into a list
 * 
 * @param filename 
 */
void load_ledger(char *filename){
	
	ifstream infile(filename);
	int f, t, a, m, ledgerID=0;
	while (infile >> f >> t >> a >> m) {
		struct Ledger l;
		l.from = f;
		l.to = t;
		l.amount = a;
		l.mode = m;
		l.ledgerID = ledgerID++;
		ledger.push_back(l);
	}
}

/**
 * @brief Remove items from the list and execute the instruction.
 * 
 * @param workerID 
 * @return void* 
 */
void* worker(void *workerID){
	int work_id = *((int *) workerID); // get workId
	Ledger *led = new Ledger; //ledger temp storage
	pthread_mutex_lock(&ledger_lock); // get and remove ledger from list
	while (ledger.empty() == false) {
		(*led) = ledger.front();
		ledger.pop_front();
		pthread_mutex_unlock(&ledger_lock); 

		if (led->mode == 0) {//D
			bank->deposit(work_id, led->ledgerID, led->from, led->amount);
		}
		else if (led->mode == 1) {//W
			bank->withdraw(work_id, led->ledgerID, led->from, led->amount);
		}
		if (led->mode == 2) {//T
			bank->transfer(work_id, led->ledgerID, led->from, led->to, led->amount);
		}
		pthread_mutex_lock(&ledger_lock); // get and remove ledger from list
	}
	pthread_mutex_unlock(&ledger_lock); // get and remove ledger from list
	free(led);


	return NULL;
}